# EcoVida — actualización 1.1

Aplicación Android educativa sobre hábitos sostenibles. Funciona sin conexión y guarda el progreso en el dispositivo.

## Novedades de esta versión
- Interfaz más limpia: el encabezado principal se muestra en Inicio y las demás secciones aprovechan mejor la pantalla.
- Navegación con transiciones suaves y avisos de logros.
- El reto diario se renueva por fecha y la racha cuenta días consecutivos.
- EcoDuelo corregido: cada jugador responde cinco preguntas (diez turnos en total).
- Se amplían las EcoIdeas con proyectos de cuidado costero, observación de biodiversidad y reducción de desechables.
- Se conserva el logo, la pantalla de bienvenida, los consejos, el juego de reciclaje y las insignias.
- Versión Android 1.1.

## Compilar en GitHub desde el celular
1. Crea un repositorio nuevo o utiliza `EcoVida-Actualizada`.
2. Sube este archivo ZIP a la raíz del repositorio, sin descomprimirlo.
3. Crea el archivo `.github/workflows/build-apk.yml` en el repositorio y pega el contenido del archivo de flujo de trabajo entregado por separado.
4. Abre la pestaña **Actions**, entra a **Crear APK EcoVida** y espera a que termine.
5. Descarga el artefacto `EcoVida-APK-v1.1` y extrae `app-debug.apk` para instalarlo.

## Nota
EcoDuelo es para dos personas en el mismo teléfono. No es multijugador en línea y no necesita crear cuentas.
